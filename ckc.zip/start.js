import './background.js';

// importScripts('background.js');
// importScripts('background.js','check.js');
//code